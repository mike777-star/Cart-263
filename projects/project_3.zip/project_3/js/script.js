


$(document).ready(setup);


function setup() {
//Step 6: Before the game starts there will be a start screen which will be...
//...removed on click.
  $("#start").on('click', showInstructions);

//Step 3: I am defining the pitch and rate of my responsive voice as random...
//...in the mean time.
  let options = {
    pitch: 1.8,
    rate: 0.8,
    onend: resetRobot
  };

  let robotState = 0;
  if (annyang) {
    console.log("started")

//Step 2: Setting up my annyang commands and functions for all three responses.
    var commands = {
      //'I am happy': iamHappy,

    };

    annyang.addCommands(commands);

    annyang.start();
    annyang.debug();

  }

//Step 6: By clicking and removing the start screen the cat will load with...
//...a set of instructions over it.
  function showInstructions() {
    $("#start").remove();
//This jquery function will remove the display none on both the cat and...
//...button classes.
    $(".robot").show();
    $(".button").show();
//After you click the instructions the play function will trigger which will...
//...remove the message as the more money button will appear.
    $("#instructions").on('click', play);
  }

  function play() {
    $("#instructions").remove();


  }



//Step 2: Defining my "iam" functions to trigger the correct frames and...
//...unique response.

  function angryRobot() {

//Step 4: I am defining the catState values for each response so the...
//...correct closed mouth frame will play after the open mouth frame.
    robotState = 1;

//Using jquery to load the first open mouth frame once.
  //  $("#normalCat").attr("src", "assets/happy_cat.png");

//Once the frame is loaded then the responsive voice with trigger.
    responsiveVoice.speak("Why did you do that", 'UK English Female', options);
  }



  //Step 5: I am creating my reset function to actually trigger the closed...
  //...mouth frames using the catState values.
  function resetCat() {

  //   if (catState === 1) {
  //     $("#normalCat").attr("src", "assets/glad_cat.png");
  //
  //   }
  //   else if (catState === 2) {
  //     $("#normalCat").attr("src", "assets/unhappy_cat.png");
  //
  }

};
