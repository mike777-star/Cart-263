


$(document).ready(setup);

// $(document).ready(function() {
//
//   $.getJSON('data/data.json')
//     .done(gotData)
//     .fail(dataError);
// });


function setup() {
//Step 6: Before the game starts there will be a start screen which will be...
//...removed on click.

let anwsers = [];
//hide all questions except first one.
$("#questionTwo").hide();
$("#questionThree").hide();
$("#questionFour").hide();
$("#questionFive").hide();
let nextQuestion =1;


  //$("#start").on('click', showInstructions);
/* anwser first question */
  $("#submit-1").click(function(){
  let inputValue  = $("#facebookFriend").val();
  if (inputValue==="") {
    // error
    console.log("not a num");
  }
//is valid
  else{
    anwsers.push(inputValue);
    nextQuestion=2;
    $("#questionOne").hide();
    $("#questionTwo").show();

  }
}); //end first question


/* anwser second question */
$("#submit-2").click(function(){
let inputValue  = $("#realFriend").val();
if (inputValue==="") {
  // error
  console.log("not a num");
}
//is valid
else{
  anwsers.push(inputValue);
    nextQuestion=3;
  $("#questionTwo").hide();
  $("#questionThree").show();

}
}); //end second question

/* anwser third question */
$("#submit-3").click(function(){
			let ele = document.getElementsByName('gender');

			for(i = 0; i < ele.length; i++) {
				if(ele[i].checked) {
        console.log(ele[i].value);
        anwsers.push(ele[i].value);
        nextQuestion=4;
        $("#questionThree").hide();
        $("#questionFour").show();
        break;
      }
		 }
}); //end third question

$("#submit-4").click(function(){
  $("#questionFour").hide();
  $("#questionFive").show();
  anwsers.push('anwser4');
  nextQuestion=5;

});

$("#submit-5").click(function(){
    anwsers.push('anwser5');
  nextQuestion=6;

  let textAnwser = ` anwser 1: ${anwsers[0]},anwser 2: ${anwsers[1]},anwser 3: ${anwsers[2]}, anwser 4: ${anwsers[3]},anwser 5: ${anwsers[4]}`;
  $("#anwser").text(textAnwser);

});



//Step 3: I am defining the pitch and rate of my responsive voice as random...
//...in the mean time.
  let options = {
    pitch: 1.8,
    rate: 0.8
    //onend: resetRobot
  };

  if (annyang) {
    console.log("started")

//Step 2: Setting up my annyang commands and functions for all three responses.
    var commands = {
      'I have :numFriends facebook friends': questionOneCommand,

    };

    annyang.addCommands(commands);

    annyang.start();
    annyang.debug();

  }

  function questionOneCommand(numFriends){
  //  console.log(numFriends);
    anwsers.push(numFriends);
    nextQuestion=2;
    $("#questionOne").hide();
    $("#questionTwo").show();

  }

// //Step 6: By clicking and removing the start screen the cat will load with...
// //...a set of instructions over it.
//   function showInstructions() {
//     $("#start").remove();
// //This jquery function will remove the display none on both the cat and...
// //...button classes.
//     $(".robot").show();
//     $(".button").show();
// //After you click the instructions the play function will trigger which will...
// //...remove the message as the more money button will appear.
//     $("#instructions").on('click', play);
//   }
//
//   function play() {
//     $("#instructions").remove();
//
//
//   }

};
